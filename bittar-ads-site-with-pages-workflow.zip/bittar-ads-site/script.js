// Bittar Ads — Scripts leves
// Atualiza o ano no footer e anima ancoras suaves
document.getElementById('year').textContent = new Date().getFullYear();

// scroll suave
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if(id.length > 1){
      e.preventDefault();
      document.querySelector(id).scrollIntoView({behavior:'smooth', block:'start'});
      const toggle = document.getElementById('menu-toggle');
      if(toggle) toggle.checked = false;
    }
  });
});
