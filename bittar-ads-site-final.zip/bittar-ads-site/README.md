# Bittar Ads — Landing Page
Site estático, moderno e responsivo, pronto para publicar (Vercel, Netlify, GitHub Pages).

## Como publicar (rápido)
- **Vercel**: crie um projeto e importe esta pasta. Deploy em 1 clique.
- **GitHub Pages**: crie um repositório, suba os arquivos e ative Pages (branch `main`, pasta `/`).
- **Netlify**: arraste e solte a pasta no app.

## Personalizações
- Troque o número do WhatsApp em `index.html` (procure por `wa.me/5599999999999`).
- Substitua o logo em `assets/logo.svg` pelo seu arquivo.
- Ajuste textos, planos e cases direto no `index.html`.
- Cores principais no topo do `styles.css` (variáveis `--accent` e `--accent-2`).

## Formulário
O formulário usa Formspree apenas como placeholder. Para receber mensagens:
1. Crie um formulário gratuito em formspree.io e troque a URL de `action`.
2. Ou substitua por um `mailto:`/WhatsApp.

## SEO básico
- Título, descrição e OG tags já preparados.
- Crie uma imagem `assets/og-cover.png` (1200×630).

## Suporte
Se quiser, me peça que personalize com sua logo, cores e copy completa.
